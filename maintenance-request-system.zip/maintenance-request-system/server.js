
const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = 3000;

const db = new Database("maintenance.db");

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('Employee', 'Manager', 'Technician'))
  );

  CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'Medium',
    status TEXT NOT NULL DEFAULT 'Submitted',
    technician_id INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (employee_id) REFERENCES users(id),
    FOREIGN KEY (technician_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS status_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id INTEGER NOT NULL,
    changed_by INTEGER NOT NULL,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    note TEXT DEFAULT '',
    changed_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (request_id) REFERENCES requests(id),
    FOREIGN KEY (changed_by) REFERENCES users(id)
  );
`);

const userCount = db.prepare("SELECT COUNT(*) AS count FROM users").get().count;

if (userCount === 0) {
  const addUser = db.prepare("INSERT INTO users (name, role) VALUES (?, ?)");
  addUser.run("Alex Employee", "Employee");
  addUser.run("Morgan Manager", "Manager");
  addUser.run("Taylor Technician", "Technician");
  addUser.run("Jordan Technician", "Technician");
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const roles = ["Employee", "Manager", "Technician"];
const statuses = ["Submitted", "In Progress", "On Hold", "Resolved"];

function getUser(id, role) {
  return db.prepare("SELECT * FROM users WHERE id = ? AND role = ?").get(id, role);
}

function recordHistory(requestId, userId, previousStatus, newStatus, note = "") {
  db.prepare(`
    INSERT INTO status_history
      (request_id, changed_by, previous_status, new_status, note)
    VALUES (?, ?, ?, ?, ?)
  `).run(requestId, userId, previousStatus, newStatus, note);
}

app.get("/api/users", (req, res) => {
  res.json(db.prepare("SELECT id, name, role FROM users ORDER BY id").all());
});

app.get("/api/requests", (req, res) => {
  const requests = db.prepare(`
    SELECT r.*, e.name AS employee_name, t.name AS technician_name
    FROM requests r
    JOIN users e ON e.id = r.employee_id
    LEFT JOIN users t ON t.id = r.technician_id
    ORDER BY r.id DESC
  `).all();

  res.json(requests);
});

app.get("/api/requests/:id/history", (req, res) => {
  const history = db.prepare(`
    SELECT h.*, u.name AS changed_by_name
    FROM status_history h
    JOIN users u ON u.id = h.changed_by
    WHERE h.request_id = ?
    ORDER BY h.id DESC
  `).all(Number(req.params.id));

  res.json(history);
});

app.post("/api/requests", (req, res) => {
  const { employeeId, title, description, category, priority } = req.body;

  if (!getUser(Number(employeeId), "Employee")) {
    return res.status(400).json({ error: "Select a valid employee." });
  }

  if (![title, description, category].every(
    value => typeof value === "string" && value.trim()
  )) {
    return res.status(400).json({ error: "Complete all required fields." });
  }

  if (!["Low", "Medium", "High"].includes(priority)) {
    return res.status(400).json({ error: "Select a valid priority." });
  }

  const result = db.prepare(`
    INSERT INTO requests (employee_id, title, description, category, priority)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    Number(employeeId), title.trim(), description.trim(),
    category.trim(), priority
  );

  recordHistory(result.lastInsertRowid, Number(employeeId), null, "Submitted", "Request created");

  res.status(201).json({
    message: "Maintenance request created.",
    id: result.lastInsertRowid
  });
});

app.patch("/api/requests/:id/assign", (req, res) => {
  const { managerId, technicianId } = req.body;

  if (!getUser(Number(managerId), "Manager")) {
    return res.status(400).json({ error: "Select a valid manager." });
  }

  if (!getUser(Number(technicianId), "Technician")) {
    return res.status(400).json({ error: "Select a valid technician." });
  }

  const request = db.prepare("SELECT * FROM requests WHERE id = ?").get(Number(req.params.id));

  if (!request) {
    return res.status(404).json({ error: "Request not found." });
  }

  db.prepare(`
    UPDATE requests
    SET technician_id = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(Number(technicianId), request.id);

  recordHistory(request.id, Number(managerId), request.status, request.status, "Assigned to technician");

  res.json({ message: "Technician assigned successfully." });
});

app.patch("/api/requests/:id/status", (req, res) => {
  const { technicianId, status, note = "" } = req.body;

  if (!getUser(Number(technicianId), "Technician")) {
    return res.status(400).json({ error: "Select a valid technician." });
  }

  if (!statuses.includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }

  if (typeof note !== "string") {
    return res.status(400).json({ error: "Invalid note." });
  }

  const request = db.prepare("SELECT * FROM requests WHERE id = ?").get(Number(req.params.id));

  if (!request) {
    return res.status(404).json({ error: "Request not found." });
  }

  if (request.technician_id !== Number(technicianId)) {
    return res.status(403).json({ error: "This request is not assigned to that technician." });
  }

  db.prepare(`
    UPDATE requests
    SET status = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(status, request.id);

  recordHistory(request.id, Number(technicianId), request.status, status, note.trim());

  res.json({ message: "Request status updated." });
});

app.listen(PORT, () => {
  console.log(`Maintenance Request System running at http://localhost:${PORT}`);
});
