
const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(
  path.join(__dirname, "maintenance.db"),
  { readonly: true }
);

console.log("DATABASE:", path.join(__dirname, "maintenance.db"));
console.log("\nTABLES:");
console.table(
  db.prepare(
    "SELECT name FROM sqlite_master WHERE type = 'table'"
  ).all()
);

console.log("\nSAVED REQUESTS:");
console.table(
  db.prepare(
    "SELECT id, title, category, priority, status FROM requests"
  ).all()
);

db.close();
