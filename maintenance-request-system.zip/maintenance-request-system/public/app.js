
const $ = (id) => document.getElementById(id);

let users = [];
let requests = [];

const escapeHTML = (value) =>
  String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;",
    '"': "&quot;", "'": "&#39;"
  })[char]);

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}

function showMessage(message, error = false) {
  const box = $("message");
  box.textContent = message;
  box.className = `message ${error ? "error" : "success"}`;
  box.hidden = false;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function statusClass(status) {
  return "status-" + status.toLowerCase().replaceAll(" ", "-");
}

function statusPill(status) {
  return `<span class="pill ${statusClass(status)}">${escapeHTML(status)}</span>`;
}

function userOptions(role, selected = "") {
  return users.filter(u => u.role === role).map(u =>
    `<option value="${u.id}" ${String(u.id) === String(selected) ? "selected" : ""}>${escapeHTML(u.name)}</option>`
  ).join("");
}

function requestOptions(items, selected = "") {
  if (!items.length) return '<option value="">No matching requests</option>';
  return items.map(r =>
    `<option value="${r.id}" ${String(r.id) === String(selected) ? "selected" : ""}>#${r.id} — ${escapeHTML(r.title)} (${escapeHTML(r.status)})</option>`
  ).join("");
}

function refreshSelectors() {
  const employee = $("employeeSelect").value;
  const manager = $("managerSelect").value;
  const technician = $("assignTechnicianSelect").value;
  const trackEmployee = $("trackEmployeeSelect").value;
  const techWorkspace = $("technicianSelect").value;
  const assignRequest = $("assignRequestSelect").value;
  const techRequest = $("technicianRequestSelect").value;

  $("employeeSelect").innerHTML = userOptions("Employee", employee);
  $("managerSelect").innerHTML = userOptions("Manager", manager);
  $("assignTechnicianSelect").innerHTML = userOptions("Technician", technician);
  $("trackEmployeeSelect").innerHTML = userOptions("Employee", trackEmployee);
  $("technicianSelect").innerHTML = userOptions("Technician", techWorkspace);

  $("assignRequestSelect").innerHTML = requestOptions(requests, assignRequest);
  $("technicianRequestSelect").innerHTML = requestOptions(
    requests.filter(r => r.technician_id && String(r.technician_id) === String(techWorkspace || r.technician_id)),
    techRequest
  );

  updateTechnicianRequests();
  renderEmployeeRequests();
}

function updateTechnicianRequests() {
  const technicianId = $("technicianSelect").value;
  const assigned = requests.filter(r => String(r.technician_id) === String(technicianId));
  const current = $("technicianRequestSelect").value;
  $("technicianRequestSelect").innerHTML = requestOptions(assigned, current);
}

function renderStats() {
  $("totalCount").textContent = requests.length;
  $("unassignedCount").textContent = requests.filter(r => !r.technician_id).length;
  $("progressCount").textContent = requests.filter(r => r.status === "In Progress").length;
  $("resolvedCount").textContent = requests.filter(r => r.status === "Resolved").length;
}

function renderTable() {
  const search = $("searchInput").value.toLowerCase();
  const status = $("statusFilter").value;

  const filtered = requests.filter(r =>
    (!status || r.status === status) &&
    [r.title, r.description, r.employee_name, r.technician_name, String(r.id)]
      .some(v => String(v || "").toLowerCase().includes(search))
  );

  $("requestsTable").innerHTML = filtered.length ? filtered.map(r => `
    <tr>
      <td>#${r.id}</td>
      <td><div class="request-title">${escapeHTML(r.title)}</div>
          <div class="subtext">${escapeHTML(r.category)}</div></td>
      <td>${escapeHTML(r.employee_name)}</td>
      <td><span class="priority-${escapeHTML(r.priority.toLowerCase())}">${escapeHTML(r.priority)}</span></td>
      <td>${statusPill(r.status)}</td>
      <td>${escapeHTML(r.technician_name || "Unassigned")}</td>
      <td>${escapeHTML(r.updated_at)}</td>
      <td><button class="small-button" data-history="${r.id}">View</button></td>
    </tr>
  `).join("") : '<tr><td colspan="8" class="empty">No requests found. Submit a request to get started.</td></tr>';
}

function cardMarkup(r, showDescription = true) {
  return `
    <article class="request-card">
      <div class="card-top">
        <div>
          <h4>#${r.id} — ${escapeHTML(r.title)}</h4>
          <div class="subtext">${escapeHTML(r.category)} · ${escapeHTML(r.created_at)}</div>
        </div>
        ${statusPill(r.status)}
      </div>
      ${showDescription ? `<p>${escapeHTML(r.description)}</p>` : ""}
      <p><strong>Priority:</strong> ${escapeHTML(r.priority)}<br>
      <strong>Employee:</strong> ${escapeHTML(r.employee_name)}<br>
      <strong>Technician:</strong> ${escapeHTML(r.technician_name || "Unassigned")}</p>
      <button class="small-button" data-history="${r.id}">View status history</button>
    </article>`;
}

function renderManager() {
  $("managerList").innerHTML = requests.length
    ? requests.map(r => cardMarkup(r)).join("")
    : '<p class="empty">No requests have been submitted yet.</p>';
}

function renderTechnician() {
  const id = $("technicianSelect").value;
  const assigned = requests.filter(r => String(r.technician_id) === String(id));
  $("technicianList").innerHTML = assigned.length
    ? assigned.map(r => cardMarkup(r)).join("")
    : '<p class="empty">No requests are assigned to this technician yet.</p>';
}

function renderEmployeeRequests() {
  if (!$("trackEmployeeSelect")) return;
  const id = $("trackEmployeeSelect").value;
  const mine = requests.filter(r => String(r.employee_id) === String(id));
  $("employeeList").innerHTML = mine.length
    ? mine.map(r => cardMarkup(r)).join("")
    : '<p class="empty">No requests found for this employee.</p>';
}

function renderAll() {
  renderStats();
  renderTable();
  renderManager();
  renderTechnician();
  renderEmployeeRequests();
  refreshSelectors();
}

async function loadData() {
  try {
    const [loadedUsers, loadedRequests] = await Promise.all([
      api("/api/users"),
      api("/api/requests")
    ]);
    users = loadedUsers;
    requests = loadedRequests;
    renderAll();
  } catch (error) {
    showMessage(error.message + " Check that the server is running.", true);
  }
}

async function refresh() {
  const oldView = document.querySelector(".tab.active")?.dataset.view || "overview";
  await loadData();
  switchView(oldView);
}

function switchView(view) {
  document.querySelectorAll(".tab").forEach(button =>
    button.classList.toggle("active", button.dataset.view === view)
  );
  document.querySelectorAll(".view").forEach(section =>
    section.hidden = section.id !== `${view}View`
  );
}

document.querySelectorAll(".tab").forEach(button => {
  button.addEventListener("click", () => switchView(button.dataset.view));
});

$("requestForm").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    const result = await api("/api/requests", {
      method: "POST",
      body: JSON.stringify({
        employeeId: $("employeeSelect").value,
        title: $("requestTitle").value,
        description: $("requestDescription").value,
        category: $("categorySelect").value,
        priority: $("prioritySelect").value
      })
    });
    event.target.reset();
    await loadData();
    switchView("overview");
    showMessage(`Request #${result.id} submitted successfully.`);
  } catch (error) {
    showMessage(error.message, true);
  }
});

$("assignForm").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    await api(`/api/requests/${$("assignRequestSelect").value}/assign`, {
      method: "PATCH",
      body: JSON.stringify({
        managerId: $("managerSelect").value,
        technicianId: $("assignTechnicianSelect").value
      })
    });
    await loadData();
    switchView("manage");
    showMessage("Technician assignment saved.");
  } catch (error) {
    showMessage(error.message, true);
  }
});

$("statusForm").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    await api(`/api/requests/${$("technicianRequestSelect").value}/status`, {
      method: "PATCH",
      body: JSON.stringify({
        technicianId: $("technicianSelect").value,
        status: $("newStatusSelect").value,
        note: $("statusNote").value
      })
    });
    $("statusNote").value = "";
    await loadData();
    switchView("technician");
    showMessage("Request status updated and history recorded.");
  } catch (error) {
    showMessage(error.message, true);
  }
});

$("technicianSelect").addEventListener("change", () => {
  updateTechnicianRequests();
  renderTechnician();
});

$("trackEmployeeSelect").addEventListener("change", renderEmployeeRequests);
$("searchInput").addEventListener("input", renderTable);
$("statusFilter").addEventListener("change", renderTable);
$("refreshButton").addEventListener("click", refresh);

document.addEventListener("click", async event => {
  const button = event.target.closest("[data-history]");
  if (!button) return;

  try {
    const history = await api(`/api/requests/${button.dataset.history}/history`);
    $("historyContent").innerHTML = history.length ? history.map(h => `
      <div class="history-item">
        <strong>${escapeHTML(h.previous_status ? h.previous_status + " → " : "")}${escapeHTML(h.new_status)}</strong>
        <p>${escapeHTML(h.changed_by_name)} · ${escapeHTML(h.changed_at)}</p>
        ${h.note ? `<p>${escapeHTML(h.note)}</p>` : ""}
      </div>
    `).join("") : "<p>No history available.</p>";
    $("historyDialog").showModal();
  } catch (error) {
    showMessage(error.message, true);
  }
});

$("closeHistoryButton").addEventListener("click", () => $("historyDialog").close());

$("todayLabel").textContent = new Date().toLocaleDateString(undefined, {
  year: "numeric", month: "short", day: "numeric"
});

loadData();
